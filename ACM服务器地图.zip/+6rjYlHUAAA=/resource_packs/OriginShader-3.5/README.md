![](https://img.shields.io/github/languages/code-size/origin0110/OriginShader?style=for-the-badge)
![](https://img.shields.io/github/languages/top/origin0110/OriginShader?style=for-the-badge)
![](https://img.shields.io/github/license/origin0110/OriginShader?style=for-the-badge)
![](https://img.shields.io/github/downloads/origin0110/OriginShader/total?style=for-the-badge)
![](https://img.shields.io/github/v/release/origin0110/OriginShader?style=for-the-badge)

请帮我完善英文翻译！谢谢！  
Please help me improve the English translation! thank you!  

Twitter https://twitter.com/linlin67601187  
Github  https://github.com/origin0110  
Discord https://discord.gg/reKUV7zGkF  

通过此文件修改设置：  
Modify the configuration from this file：  
OriginShader/shaders/glsl/Users/Set.txt  
